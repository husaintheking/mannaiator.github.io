var c = new AudioContext();
var canvas = document.querySelector("#canv1");
var ctx = canvas.getContext("2d");
//var o = c.createOscillator();
var analyser = c.createAnalyser();
//o.connect(analyser);
//o.connect(c.destination);
//o.start();
var bufferLength = analyser.frequencyBinCount;
var dataArray = new Uint8Array(bufferLength);

function drawSamples(){
  analyser.getByteTimeDomainData(dataArray);
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.beginPath();
  for (var i=0; i<canvas.width; i++) {
    ctx.lineTo(i,dataArray[i]-canvas.height*0.8)
  }
  ctx.stroke();
  requestAnimationFrame(drawSamples);
}


//var g = c.createGain();
//g.connect(c.destination);

var gates=[];

function attack(freq) {
  var o = c.createOscillator();
  var g = c.createGain();
  o.connect(g);
  g.connect(analyser);
  analyser.connect(c.destination);
  o.frequency.value = freq;
  g.gain.value = 0;
  var now = c.currentTime;
  g.gain.linearRampToValueAtTime(1,now+0.1);
  //g.gain.linearRampToValueAtTime(0,now+0.6);
  o.start();
  gates[freq] = g;
}

function release(freq) {
  gates[freq].gain.linearRampToValueAtTime(0,c.currentTime+0.8);
}

tones = [] //note
steps = [] //tasti
for(var i=0;i<25;i++) {
  tones[i] = Math.round(440*Math.pow(2,1/12)**i);
  steps[i] = document.querySelector("#s"+i);
  }
keys = "qwertyuiopasdfghjklzxcvbn"

document.querySelectorAll(".step").forEach(toggleStep)

function toggleStep(step){
  step.onclick= clickOnKeyBoard
}

function clickOnKeyBoard(step){
  step.classList.toggle("clicked-step")
}

document.onkeydown = function(e) {
  clickOnKeyBoard(steps[keys.indexOf(e.key)])
  if(!e.repeat){
    attack(tones[keys.indexOf(e.key)])
  }
}

document.onkeyup = function(e) {   
  clickOnKeyBoard(steps[keys.indexOf(e.key)]);
  release(tones[keys.indexOf(e.key)]);
  drawSamples();       
}

document.querySelector